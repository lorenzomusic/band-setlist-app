import AISetlistBuilder from '../../components/AISetlistBuilder';

export default function AISetlistPage() {
  return <AISetlistBuilder />;
} 