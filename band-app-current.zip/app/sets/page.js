import SetBuilder from '../../components/SetBuilder';

export default function SetsPage() {
  return <SetBuilder />;
} 