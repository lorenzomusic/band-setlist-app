import SongManager from '../../components/SongManager';

export default function SongsPage() {
  return <SongManager />;
} 