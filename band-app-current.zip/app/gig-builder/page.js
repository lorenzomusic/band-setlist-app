import GigBuilder from '../../components/GigBuilder';

export default function GigBuilderPage() {
  return <GigBuilder />;
} 