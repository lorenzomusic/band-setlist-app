import PerformanceTracker from '../../components/PerformanceTracker';

export default function PerformancePage() {
  return <PerformanceTracker />;
} 