import GigManager from '../../components/GigManager';

export default function GigsPage() {
  return <GigManager />;
} 