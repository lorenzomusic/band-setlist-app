import Analytics from '../../components/Analytics';

export default function AnalyticsPage() {
  return <Analytics />;
} 